<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WatchedSeason extends Model
{
    //
}
