
function submitVal(num) {
    document.getElementById("setPictureOption").value=num;
    document.getElementById("changePictureForm").submit();
}
