<footer id="footer" class="bg-one footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">


                <!-- copyright -->
                <div class="copyright text-center">
                    <p>PSIći team, copyright &copy; 2018. Sva prava zadržana.</p>
                </div>
                <!-- /copyright -->

            </div>
            <!-- end col lg 12 -->
        </div>
        <!-- end row -->
    </div>
    <!-- end container -->
</footer>