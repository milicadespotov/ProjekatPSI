<?php $__env->startSection('content'); ?>
 <div class = "backgroundLogin" style="width:100%">
<div class="container-fluid" style="width:100%">

    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card" style = "margin-top: 40px;">
                <div class="card-header color" > <h1> <?php echo e(__('Jednu prijavu ste daleko od galaksije serija: ')); ?> </h1> </div>
                <br> <br>  <br>
                <div class="card-body" style = "margin-top: 40px;">
                    <form method="POST" action="<?php echo e(route('login')); ?>" class = "contact-form fadeInUp" data-wow-duration="500ms" data-wow-delay="300ms">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="username" style = "font-size: 18px" class="col-sm-4 col-form-label text-md-right color"><?php echo e(__('Username: ')); ?></label>

                            <div class="col-md-6">
                                <input id="username"  placeholder="unesite korisniko ime" class="form-control<?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" name="username" value="<?php echo e(old('username')); ?>" style = "border-color: <?php echo e($errors->has('username') ? 'deeppink' : ''); ?>" autofocus>

                                <?php if($errors->has('username')): ?>
                                    <span class="invalid-feedback" style ="color: deeppink">
                                        <?php echo e($errors->first('username')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right color" style = "font-size: 18px;"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" placeholder =  "unesite lozinku" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" >

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-6 offset-md-4">
                                <div class="checkbox color">
                                    <label>
                                        <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> <?php echo e(__('Remember Me')); ?>

                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <div class = "cf-submit">
                                    <button type="submit" class="btn btn-transparent">
                                        <?php echo e(__('Login')); ?>

                                    </button>
                                </div>

                                <div class = "">
                                        <a class="btn replay" href="<?php echo e(route('password_request')); ?>">
                                            <?php echo e(__('Forgot Your Password?')); ?>

                                        </a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <br> <br> <br> <br> <br> <br> <br> <br> <br>  <br>

</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>