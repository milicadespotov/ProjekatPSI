<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <br>
        <br>
        <br>
        <div class="row">
            <div class="col-lg-4 ">

                <div class="blog-title">
                    <h1>
                       <a href="<?php echo e(route('showseries', ['content_id'=>$episode->seriesId()])); ?>" ><?php echo e($episode->seriesName()); ?></a> - <a href="<?php echo e(route('season', ['id'=>$episode->seasonId()])); ?>" ><?php echo e($episode->seasonName()); ?></a> - <?php echo e($content->name); ?>


                    </h1>
                </div>

            </div>
            <br>
            <div class="col-lg-8">

                <div class="blog-title">
                   <?php echo $__env->make('rating.rate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php if(Auth::check()): ?>
                        <?php if($isWatched == null): ?>

                            <a href="<?php echo e(route('updatewatched',['id'=>$episode->content_id])); ?>">
                                <img src = "<?php echo e(asset('img/w.png')); ?>" style = "width: 20px; height: auto">
                                Označi kao odgledano
                            </a>

                        <?php else: ?>


                            <a href="<?php echo e(route('updateunwatched',['id'=>$episode->content_id])); ?>">
                                <img  class = "img-fluid" src = "<?php echo e(asset('img/ww.png')); ?>" style = "width: 20px; height:auto">
                                <i> Odgledano </i>
                            </a>

                        <?php endif; ?>



                    <?php endif; ?>
                </div>

                <div>
                    <?php if(Auth::check() && Auth::user()->is_admin==true): ?>
                        <a href="#myModal1" data-toggle="modal">
                            <input type="submit" value="Obrisi epizodu" class="btn btn-transparent">
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <!-- End col-lg-12 -->
        </div>
        <br>
        <br>

        <?php if(Auth::check()): ?>

            <div class="modal" id="myModal1" style="margin-top:15%;color:black;">
                <div class="modal-dialog">
                    <div class="modal-content" style="background-color:#2B2C30;color:white">
                        <div class="modal-header">
                            <h5 class="modal-title" style="font-size:20px">Brisanje epizode
                                <button style="margin-bottom:10px;" type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button></h5>
                        </div>
                        <div class="modal-body">
                            <p>Da li ste sigurni da želite da uklonite ovu epizodu?</p>
                        </div>
                        <div class="modal-footer">
                            <form method="post" action="<?php echo e(route('episoderemove',['id'=>$episode->content_id])); ?>">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="submit" class="btn btn-transparent" value="Potvrdi">
                                <button type="button" class="btn btn-transparent" data-dismiss="modal">Odustani</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>


        <div class="row" style="font-size: 15px">

            <div class="col-md-8">
                <div class="row">
                <!--Glavna slika	-->
                    <div class="col-md-6">
                <center><?php $flag=false; ?>

                    <?php $__currentLoopData = $content->pictures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($picture->main_picture==true){ $flag=true; ?>
                            <img src="<?php echo e(asset('img/img/content/'.$picture->path)); ?>" style="width:90%;height:auto">
                            <?php } ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php if(!$flag) { ?>
                    <img src="<?php echo e(asset('img/default_content.png')); ?>" style="width:60%;height:auto">

                    <?php }?>


                    <?php if(Auth::check() && Auth::user()->is_admin==true): ?>
                        <a href="<?php echo e(route('editepisode',['episode'=>$episode->content_id])); ?>">
                            <input type="submit" value="Izmeni informacije" class="btn btn-transparent">
                        </a>
                    <?php endif; ?>


                </center>
                <br>
                    </div>


                    <div class="col-md-6">
                <h4>Opis: </h4>
                <p style="width:100%;word-wrap: break-word;font-size:16px;">
                    <?php echo e($content->description); ?>

                </p>

                    </div>
                </div>
                <div class="row" >
                    <div class="col-md-12">


                        <div id="comments" class="comments-section ">
                            <h4><?php echo e($numcomments); ?> komentara</h4>
                            <ol class="comment-list">
                                <li id="comment-1">

                                    <!-- Svaki komentar(foreach) ide u ovaj comment wrap-->
                                    <!--Znaci ovdje ce ici foreach-->
                                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <?php if($comment->contains_spoiler == 0): ?>
                                            <div class="comment-wrap">
                                                <div class="author-avatar pull-left">
                                                    <!--Slika korisnika-->
                                                    <img src="img/avatar.png" alt="">
                                                </div>
                                                <div class="author-comment">
                                                    <!--Ime korisnika-->
                                                    <cite class="pull-left">
                                                        <!-- DODATI LINK KA PROFILU KORISNIKA -->
                                                        <a href="#">
                                                            <?php  $user = App\User::find($comment->user_id)  ?>
                                                            <?php echo e($user->username); ?>

                                                        </a>
                                                    </cite>
                                                    <?php if(Auth::check() && Auth::user()->is_admin==true): ?>

                                                        <a href="<?php echo e(route('deletecomment',['id'=>$comment->id])); ?>" class="replay pull-right">Ukloni komentar</a><br>
                                                        <a href="<?php echo e(route('updatespoiler',['id'=>$comment->id])); ?>" class="replay pull-right">Sadrzi spojlere</a>
                                                    <?php endif; ?>
                                                <!-- PRIAKZI MU KOMENTAR AKO JE ON NJEGOV KREATOR-->
                                                    <?php if(Auth::check() && Auth::user()->is_admin==false && Auth::user()->id==$comment->user_id): ?>

                                                        <a href="<?php echo e(route('deletecomment',['id'=>$comment->id])); ?>" class="replay pull-right">Ukloni komentar</a>
                                                    <?php endif; ?>

                                                    <div style="clear:both"></div>
                                                    <div class="comment-meta">
                                                        <!--Datum komentara-->
                                                        <i class="fa fa-calendar"></i> <?php echo e($comment->created_at->format('m/d/Y')); ?>

                                                    </div>
                                                    <div class="comment-content">
                                                        <p style="width:100%;word-wrap: break-word;">
                                                            <?php echo e($comment->description); ?>

                                                        </p>
                                                    </div>
                                                </div>


                                            </div>
                                            <br>
                                        <?php else: ?>
                                            <div class="comment-wrap">
                                                <div class="author-avatar pull-left">
                                                    <!--Slika korisnika-->
                                                    <img src="img/avatar.png" alt="">
                                                </div>
                                                <div class="author-comment">
                                                    <!--Ime korisnika-->
                                                    <cite class="pull-left">

                                                        <a href="#">
                                                            <?php  $user = App\User::find($comment->user_id) ?>
                                                            <?php echo e($user->username); ?>

                                                        </a>
                                                    </cite>
                                                    <?php if(Auth::check() && Auth::user()->is_admin==true): ?>

                                                        <a href="<?php echo e(route('deletecomment',['id'=>$comment->id])); ?>" class="replay pull-right">Ukloni komentar</a>
                                                        <br>
                                                        <a href="<?php echo e(route('updatespoilerremove',['id'=>$comment->id])); ?>" class="replay pull-right">Ne sadrzi spojlere</a>
                                                        <br>
                                                        <a href="#<?php echo e($comment->id); ?><?php echo e($comment->user_id); ?>" data-toggle="collapse" class="replay pull-right">Prikazi komentar</a>
                                                    <?php endif; ?>
                                                <!-- PRIAKZI MU KOMENTAR AKO JE ON NJEGOV KREATOR-->
                                                    <?php if(Auth::check() && Auth::user()->is_admin==false && Auth::user()->id==$comment->user_id): ?>

                                                        <a href="<?php echo e(route('deletecomment',['id'=>$comment->id])); ?>" class="replay pull-right">Ukloni komentar</a>
                                                        <br>


                                                    <?php endif; ?>
                                                    <?php if(Auth::check() && Auth::user()->is_admin==false): ?>
                                                        <a href="#<?php echo e($comment->id); ?><?php echo e($comment->user_id); ?>" data-toggle="collapse" class="replay pull-right">Spoiler! Prikazi komentar</a>
                                                    <?php endif; ?>
                                                    <div style="clear:both"></div>
                                                    <div class="comment-meta">
                                                        <!--Datum komentara-->
                                                        <i class="fa fa-calendar"></i> <?php echo e($comment->created_at->format('m/d/Y')); ?>

                                                    </div>
                                                    <div class="comment-content"  >

                                                        <p class="collapse" id="<?php echo e($comment->id); ?><?php echo e($comment->user_id); ?>"  style="width:100%;word-wrap: break-word;">
                                                            <?php echo e($comment->description); ?>

                                                        </p>
                                                    </div>
                                                </div>



                                            </div>
                                            <br>




                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </li>
                            </ol>
                        </div>

                            <div class="col-md-12">
                                <center>
                                    <?php echo e($comments->links()); ?>

                                </center>
                            </div>
                        <!-- Forma za postavljanje komentara-->
                        <div class="col-md-12">
                            <h3>Ostavi komentar</h3>
                            <form id="comment-form" method="post" action="<?php echo e(route('addcomment')); ?>">
                                <input type="hidden" name="episode_id" value=<?php echo e($episode->content_id); ?>  lenght="30"/><!--Id epizode-->
                            <?php echo csrf_field(); ?>
                            <!-- End .form-group -->
                                <div class="form-group">
                                    <textarea class="form-control" placeholder="Komentar *" id="comment" name="comment" rows="5" cols="5" required></textarea>
                                </div>
                                <div class="form-group">
                                    <input type="checkbox" name="spoiler" value="1"> &nbsp; Sadrzi spojler
                                </div>
                                <!-- End .form-group -->
                                <div class="form-group">
                                    <input type="submit" id="post-comment" value="Postavi komentar" class="btn btn-transparent">
                                </div>
                                <!-- End .form-group -->
                            </form>
                        </div>

                    </div>

                </div>



            </div>


            <div class="col-md-4" style="font-weight: bold">
                <center>
                    <?php if($content->pictures !=null): ?>
                    <h3>Slike</h3>
                        <?php endif; ?>
                </center>
                <center>

                    <?php $__currentLoopData = $content->pictures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(asset('img/img/content/'.$picture->path)); ?>" data-lightbox="pics">
                                <img src="<?php echo e(asset('img/img/content/'.$picture->path)); ?>" style="width:300px;height:auto;margin-bottom:20px">
                        </a>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </center>
                <?php if(Auth::check() && Auth::user()->is_admin==true): ?>
                    <center>
                        <a href="#">
                            <input type="submit" value="Dodaj sliku" class="btn btn-transparent">
                        </a>
                    </center>
                <?php endif; ?>
            </div>

        </div>



        <br>

        <br>
        <br>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>