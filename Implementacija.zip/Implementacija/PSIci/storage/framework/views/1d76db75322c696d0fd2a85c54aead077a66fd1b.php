<?php $__env->startSection('content'); ?>
    <div class = "backgroundLoginI" style="width:100%">
        <div class="container-fluid" style="width:100%">



            <br> <br> <br> <br>
            <h3 style = "color: grey;"> <center> <?php echo e(__('Napravite svoj nalog i postanite deo galaksije pravih zaljubljenika u serije!')); ?> </center></h3>
            <br> <br> <br>

                <form method="POST" enctype= "multipart/form-data" class = "contact-form fadeInUp color" data-wow-duration="500ms" data-wow-delay="300ms" action="<?php echo e(route('register')); ?>">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <div class = "col-md-12">
                    <?php echo csrf_field(); ?>
                    <div class="col-md-6 pull-left">
                        <!-- User name REQUESTED WANT -->
                        <div class="form-group row">
                            <label for = "username" class="col-md-4 col-form-label text-md-right" style = "font-size: 18px"><?php echo e(__('Korisničko ime:*')); ?></label>

                            <div class="col-md-6">
                                <input id="username" type="text" class="form-control<?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" style = "<?php echo e($errors->has('username')?'border-color: deeppink': ''); ?>" name="username" value="<?php echo e(old('username')); ?>"  autofocus>

                                <?php if($errors->has('username')): ?>
                                    <span class="invalid-feedback" style = "color: deeppink">
                                            <?php echo e($errors->first('username')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!-- Name NOT REQUEST -->
                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right" style = "font-size: 18px"   style = ""><?php echo e(__('Ime: ')); ?></label>
                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" style = "<?php echo e($errors->has('name')?'border-color: deeppink':''); ?>" autofocus>
                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" style = "color: deeppink">
                                                <?php echo e($errors->first('name')); ?>

                                            </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="surname" class="col-md-4 col-form-label text-md-right" style = "font-size: 18px"><?php echo e(__('Prezime:')); ?></label>

                            <div class="col-md-6">
                                <input id="surname" type="text" class="form-control<?php echo e($errors->has('surname') ? ' is-invalid' : ''); ?>" name="surname"  value="<?php echo e(old('surname')); ?>"   style = "<?php echo e($errors->has('surname')?'border-color: deeppink':''); ?>" autofocus>
                                <?php if($errors->has('surname')): ?>
                                    <span class="invalid-feedback" style = "color: deeppink">
                                                    <strong><?php echo e($errors->first('surname')); ?></strong>
                                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="gender" class="col-md-4 col-form-label text-md-right" style = "font-size: 18px;"><?php echo e(__('Pol:')); ?></label>

                            <div class="col-md-6">
                                <div class = "radio">
                                    <label> <input type = "radio" name = "gender" value = "m"> Muski </label>
                                </div>
                                <div class = "radio">
                                    <label > <input type = "radio" name = "gender" value = "f"> Zenski</label>
                                </div>
                                <?php if($errors->has('gender')): ?>
                                    <span class="invalid-feedback" style = "color: deeppink">
                                                <strong><?php echo e($errors->first('gender')); ?></strong>
                                            </span>
                                <?php endif; ?>
                            </div>
                        </div>


                        <div class="form-group row">
                            <label for = "security_question" class="col-md-4 col-form-label text-md-right" style = "font-size: 18px"><?php echo e(__('Bezbednosno pitanje:*')); ?></label>

                            <div class="col-md-6">
                                <input id="security_question" type="text" class="form-control<?php echo e($errors->has('security_question') ? ' is-invalid' : ''); ?>" name="security_question" value="<?php echo e(old('security_question')); ?>"   style = "<?php echo e($errors->has('security_question')?'border-color: deeppink':''); ?>"  autofocus>

                                <?php if($errors->has('security_question')): ?>
                                    <span class="invalid-feedback" style = "color: deeppink">
                                                <?php echo e($errors->first('security_question')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                    </div>
                    <div class="col-md-6 pull-right">
                        <div class="form-group row">
                            <label for = "answer" class="col-md-4 col-form-label text-md-right" style = "font-size: 18px;"><?php echo e(__('Odgovor:*')); ?></label>

                            <div class="col-md-6">
                                <input id="answer" type="text" class="form-control<?php echo e($errors->has('answer') ? ' is-invalid' : ''); ?>" name="answer" value="<?php echo e(old('answer')); ?>" style = "<?php echo e($errors->has('answer')?'border-color: deeppink':''); ?>"  autofocus>

                                <?php if($errors->has('answer')): ?>
                                    <span class="invalid-feedback" style = "color: #ff0071">
                                                <?php echo e($errors->first('answer')); ?>

                                            </span>
                                <?php endif; ?>
                            </div>
                        </div>



                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right" style = "font-size: 18px;"><?php echo e(__('E-Mail Adresa:*')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" style = "<?php echo e($errors->has('email')?'border-color: deeppink':''); ?>"  >

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" style = "color: #ff0071">
                                               <?php echo e($errors->first('email')); ?>

                                            </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right" style = "font-size: 18px;" ><?php echo e(__('Lozinka:*')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" style = "<?php echo e($errors->has('password')?'border-color: deeppink':''); ?>" >

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" style = "color: deeppink">
                                                <?php echo e($errors->first('password')); ?>

                                            </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right" style = "font-size: 18px;"> <?php echo e(__('Loznka Ponovljena:*')); ?></label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirm" style = "<?php echo e($errors->has('password_confirm')?'border-color: deeppink':''); ?>"  >
                                <?php if($errors->has('password_confirm')): ?>
                                    <span class="invalid-feedback" style = "color: deeppink">
                                                <?php echo e($errors->first('password_confirm')); ?>


                                            </span>
                                <?php endif; ?>

                            </div>
                        </div>

                        <div class = "form-group row">
                            <label for="birth_date" class="col-md-4 col-form-label text-md-right" style = "font-size: 18px;"><?php echo e(__('Rođenje:*')); ?></label>
                            <div class="col-md-6">
                                <input id="date" type="date" name = "birth_date"  style = "<?php echo e($errors->has('birth_date')?'border-color: deeppink':''); ?>" class = "form-control">
                                <?php if($errors->has('birth_date')): ?>
                                    <span class="invalid-feedback" style = "color: deeppink">
                                                <strong><?php echo e($errors->first('birth_date')); ?></strong>
                                            </span>
                                <?php endif; ?>
                            </div>
                        </div>


                        <div class = "form-group row" >
                            <label for="picture" class="col-md-4 col-form-label text-md-right" style = "font-size: 18px;"><?php echo e(__('Profilna fotografija: ')); ?></label>
                            <br>
                            <div class="col-md-6">
                                <table>
                                    <tr>
                                        <td>

                                            <input id="picture" name = "picture" type="file" class = "form-control input-file"  value="<?php echo e(Request::old('picture')); ?>" style = "display: none;">
                                            <img src = "<?php echo e(asset('img/default_content.png')); ?>" id = "img" class = "img" style = "width: 140px; height: 150px; background-color: #2B2C30">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <input type = "button" name = "browse_file" id = "browse_file" class = "btn btn-transparent form-control"  value = "Dodaj fotografiju">
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>

                    </div>
                    </div>
                    <center>
                    <div class="form-group row mb-0 ">
                        <button type="submit" class="btn btn-transparent">
                            <?php echo e(__('Register')); ?>

                        </button>
                    </div>
                    </center>
                </form>
                <p> Polja koja pored naziva imaju * su obavezna! </p>


            </div>

        <br> <br> <br> <br>user
    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>