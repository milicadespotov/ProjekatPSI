<?php $__env->startSection('content'); ?>
    <div class="container">
        <br>
        <div class="row">
            <div class="col-md-12 ">

                <div class="blog-title">
                    <h1>PREDSTOJEĆE SERIJE</h1>
                </div>
                <hr>
                <br>
                <br>
            </div>
        </div>
        <?php for($i=0;$i<sizeof($upcoming);$i++): ?>
            <div class="row">

                <div class="col-md-12">


                    <article class="entry wow fadeInDown"  data-wow-duration="1000ms" data-wow-delay="300ms">
                        <div class="col-md-4">
                            <div class="post-thumb" >
                                <a href="#">
                                    <!-- PROVJERITI U KOM FOLDERU JE SLIKA I PROMIJENITI PUTANJU -->
                                    <?php if($picturesUpcoming[$i]!=null): ?>
                                        <a href="<?php echo e(asset('img/img/content/'.$picturesUpcoming[$i]->path)); ?>" data-lightbox="MPpic">
                                            <img src="<?php echo e(asset('img/img/content/'.$picturesUpcoming[$i]->path)); ?>" style="width:100%">
                                        </a>
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('img/default_content.png')); ?>" style="width:100%">
                                    <?php endif; ?>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="post-excerpt">
                                <!-- DODATI RUTU KOJA VODI NA EPIZODU-->
                                <h3><a href="<?php echo e(route('showseries',['id'=>$upcoming[$i]->id])); ?>"><?php echo e($upcoming[$i]->name); ?></a></h3>

                                <br>



                                <p style="word-wrap: break-word;"> <?php echo e($upcoming[$i]->description); ?> </p>
                            </div>
                            <div class="post-meta">
                                 <span class="post-date">
                                                <i class="fa fa-calendar"></i><?php echo e(\Carbon\Carbon::parse($upcoming[$i]->release_date)->format('d/m/Y')); ?>

                                </span>
                                <span class="comments">
                                                <i class="fa fa-star"></i><?php echo e($upcoming[$i]->rating); ?>

                                </span>
                                <span class="comments">
                                    <i class="fa fa-image"></i><?php echo e($upcoming[$i]->number_of_pictures); ?>

                                </span>

                            </div>
                        </div>
                    </article>





                </div>

            </div>
            <br><br>

            <hr>
        <?php endfor; ?>


        <div class="row">
            <div class="col-md-12">
                <center>
                    <?php echo e($upcoming->links()); ?>

                </center>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>