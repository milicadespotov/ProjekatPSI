<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row" style="margin-top:15px;margin-bottom:15px;">
            <?php $i=0; ?>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $i=$i+1;?>
            <div class="col-lg-6">
                <div class="row" style="margin-bottom:15px">
                    <div class="col-lg-4">
                        <?php if($user->picture_path!=null): ?>
                            <img style="width:100%" src="<?php echo e(asset('img/img/users/'.$user->picture_path)); ?>">
                            <?php else: ?>
                            <img style="width:100%" src="<?php echo e(asset('img/avatar.png')); ?>">
                            <?php endif; ?>
                    </div>
                    <div class="col-lg-8">
                        <h5><?php echo e($user->name); ?> <?php echo e($user->surname); ?></h5>
                        <br>
                        <input type="submit" value="Unapredi nalog" class="btn btn-transparent" data-toggle="modal" data-target="#myModal<?php echo e($i); ?>">

                    </div>
                </div>

                        <div class="modal" id="myModal<?php echo e($i); ?>" style="margin-top:15%;color:black;">
                            <div class="modal-dialog">
                                <div class="modal-content" style="background-color:#2B2C30;color:white">
                                    <div class="modal-header">
                                        <h5 class="modal-title" style="font-size:20px">Unapredjivanje naloga
                                            <button style="margin-bottom:10px;" type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button></h5>
                                    </div>
                                    <div class="modal-body">
                                        <p>Da li ste sigurni da želite da unapredite ovaj nalog?</p>
                                    </div>
                                    <div class="modal-footer">

                                        <form method="post" action="<?php echo e(route('confirm_admin', ['id'=>$user->id])); ?>">
                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                            <?php echo csrf_field(); ?>
                                            <input type="submit" class="btn btn-transparent" value="Potvrdi"></input>
                                            <button type="button" class="btn btn-transparent" data-dismiss="modal">Odustani</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
            </div>
        <?php if($i % 2 ==0): ?>
        </div>
        <div class="row">
            <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>
<center>
    <?php echo e($users->links()); ?>

</center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>