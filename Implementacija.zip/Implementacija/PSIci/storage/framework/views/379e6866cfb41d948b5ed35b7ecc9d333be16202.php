<?php $__env->startSection('content'); ?>
    <div class="backgroundLogin">
        <br>
        <br>
        <div class="container-fluid">
            <div class="row" style="font-size:18px;color:#8A2BE2">
                <div class="col-md-3">&nbsp;</div>
                <div class="col-md-6">
                    <iframe width="560" height="315" src="https://www.youtube.com/embed/<?php echo e($content->trailer); ?>" style="width:100%;" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                </div>
                <div class="col-md-3">&nbsp;</div>
            </div>
            <br>
            <br>
            <br>
            <br>
            <div class="row" style="font-size:22px;color:#8A2BE2">
                <div class="col-md-12">
                <form id="info-form" enctype= "multipart/form-data" method="post" action="<?php echo e(route('addtrailerpost')); ?>" class = "contact-form fadeInUp" data-wow-duration="500ms" data-wow-delay="300ms">
                    <?php echo csrf_field(); ?>
                    <fieldset>
                        <div class="col-md-2">
                            &nbsp;
                        </div>


                        <div class="col-md-8">
                            <div class="form-group ">
                                <input type="hidden" name="id" value="<?php echo e($content->id); ?>">
                               <center> <label class="control-label" for="trailer" >Youtube link do novog trejlera:</label></center>

                                <input id="trailer" name="trailer" placeholder="Unesite link" class="form-control input-md" type="text" >
                                <center><div style="color:deeppink">  <?php echo e($errors->first('trailer')); ?></div></center>
                            </div>
                            <br>


                            <div class="form-group">

                                <center>
                                    <button type="submit" class="btn btn-transparent">Potvrdi</button>
                                    <a href="<?php echo e(route('redirectback',['id' => $content->id])); ?>">
                                        <button type="button" class="btn btn-transparent" value="">Nazad</button>
                                    </a>
                                </center>

                            </div>
                        </div>
                        <div class="col-md-2">
                            &nbsp;
                        </div>
                    </fieldset>
                </form>
                </div>
            </div>


        </div>


        <br>
        <br>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>