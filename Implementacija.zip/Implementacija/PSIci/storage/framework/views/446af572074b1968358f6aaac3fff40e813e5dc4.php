<?php $__env->startSection('content'); ?>


    <br>
    <div class="container-fluid">
        <div class="row">
        <div class="col-md-6">
            <center>
                <h2>Najpopularnije serije</h2>
                <br>
                <br>
            </center>
            <div class="row">


                <?php for($i=0;$i<sizeof($mostPopular);$i++): ?>

                <div class="col-md-12" style="margin-bottom:10px">
                    <div class="col-md-4">

                        <?php if($picturesMP[$i]!=null): ?>
                            <img src="<?php echo e(asset('img/img/content/'.$picturesMP[$i]->path)); ?>" style="width:100%">
                        <?php else: ?>
                            <img src="<?php echo e(asset('img/default_content.png')); ?>" style="width:100%">
                        <?php endif; ?>



                    </div>
                    <div class="col-md-8">
                        <h4><a href="<?php echo e(route('showseries',['id'=>$mostPopular[$i]->id])); ?>"><?php echo e($mostPopular[$i]->name); ?></a></h4>
                       <p style="width:100%;word-wrap: break-word;">
                           <?php echo e($mostPopular[$i]->description); ?>

                       </p>

                    </div>

                </div>




                <?php endfor; ?>


            </div>
        </div>
        <div class="col-md-6">
            <center>
                <h2>Predstojeće serije</h2>
                <br>
                <br>
            </center>
            <div class="row">

                <?php for($i=0;$i<sizeof($upcoming);$i++): ?>
                <div class="col-md-12" style="margin-bottom:10px">
                    <div class="col-md-4">
                        <?php if($picturesUpcoming[$i]!=null): ?>
                            <img src="<?php echo e(asset('img/img/content/'.$picturesUpcoming[$i]->path)); ?>" style="width:100%">
                        <?php else: ?>
                            <img src="<?php echo e(asset('img/default_content.png')); ?>" style="width:100%">
                        <?php endif; ?>
                    </div>
                    <div class="col-md-8">
                        <h4><a href="<?php echo e(route('showseries',['id'=>$upcoming[$i]->id])); ?>"><?php echo e($upcoming[$i]->name); ?></a></h4>
                        <p style="width:100%;word-wrap: break-word;">
                            <?php echo e($upcoming[$i]->description); ?>

                        </p>

                    </div>

                </div>


                <?php endfor; ?>

            </div>
        </div>

    </div>
        <div class="row">
            <div class="col-md-6">
                <center>
                    <a href="<?php echo e(route('mostpopular')); ?>">
                        <input type="submit" value="Pogledaj vise" class="btn btn-transparent">
                    </a>
                </center>
            </div>
            <div class="col-md-6">
                <center>
                    <a href="<?php echo e(route('upcoming')); ?>">
                        <input type="submit" value="Pogledaj vise" class="btn btn-transparent">
                    </a>
                </center>
            </div>
        </div>

    </div>

    <br>
    <br>
    <br>
    <br>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>