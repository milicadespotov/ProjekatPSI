<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <br>
    <br>
    <br>
<?php for($i=0;$i<sizeof($tvshows);$i++): ?>
    <div class="row">

        <div class="col-md-4">

            <?php if($pictures[$i]==null): ?>
                <img style="width:100%" src="<?php echo e(asset('img/default_content.png')); ?>">
            <?php else: ?>
                <img style="width:100%" src="<?php echo e(asset('img/img/content/'.$pictures[$i]->path)); ?>">
            <?php endif; ?>
        </div>
        <div class="col-md-8" >

            <table style="border-collapse: separate;border-spacing: 1.5em;">
                <tr colspan="2">
                    <td>
                        <h2>
                           <strong>
                               <a href="<?php echo e(route('showseries',['content_id'=>$contents[$i]->id])); ?>"><?php echo e($contents[$i]->name); ?></a>
                           </strong>


                        </h2>
                    </td>
                </tr>
                <tr>
                    <td >
                        <!-- Privremeno rjesenje za prelom teksta-->
                        <div class="col-md-6">

                            <p style="width:100%;word-wrap: break-word;">
                                <?php echo e($contents[$i]->description); ?>

                            </p>
                        </div>

                    </td>
                </tr>
                <tr>
                    <td><strong>Glumci:</strong></td>
                    <td width="30%">
                        <?php $__currentLoopData = $actors[$i]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            |<a href="/search?selectionForm=glumci&search=<?php echo e($actor->name); ?>"><?php echo e($actor->name); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        |
                    </td>
                </tr>
                <tr>
                    <td><strong>Režiseri:</strong></td>
                    <td>
                        <?php $__currentLoopData = $directors[$i]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $director): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            |<a href="/search?selectionForm=reziseri&search=<?php echo e($director->name); ?>"><?php echo e($director->name); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        |
                    </td>
                </tr>
                <tr>
                    <td><strong>Žanr:</strong></td>
                    <td>
                        <?php $__currentLoopData = $genres[$i]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            |<a href="/search?selectionForm=<?php echo e($genre->name); ?>&search="><?php echo e($genre->name); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        |
                    </td>
                </tr>
            </table>
        </div>

    </div>
    <br>
<?php endfor; ?>
    
</div>

<br> <br> <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>