<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <br>
        <br>
        <br>

        <div class="row">
            <div class="col-lg-4 ">

                <div class="blog-title">
                    <h1><a href="<?php echo e(route('showseries',['content_id'=>$season->seriesId()])); ?>"><?php echo e($season->seriesName()); ?></a> - <?php echo e($season->season_number); ?>. <?php echo e($content->name); ?>




                    </h1>
                    <?php if(Auth::check() && Auth::user()->is_admin==true): ?>

                        <center>


                            <form method="get" action="<?php echo e(route('addepisode',['id'=>$content->id])); ?>">
                                <a href="#myModal2" data-toggle="modal">
                                    <input type="submit" value="Obrisi sezonu" class="btn btn-transparent">
                                </a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="submit" value="Dodaj epizodu" class="btn btn-transparent">
                            </form>
                        </center>
                    <?php endif; ?>
                </div>

            </div>
            <div class="col-lg-4">
                <div class="blog-title">
                    <?php echo $__env->make('rating.rate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <?php if($isWatched == null): ?>

                        <a href="<?php echo e(route('update_watched_season',['id'=>$season->content_id])); ?>">
                            <img src = "<?php echo e(asset('img/w.png')); ?>" style = "width: 20px; height: auto">
                            Označi kao odgledano
                        </a>

                    <?php else: ?>


                        <a href="<?php echo e(route('update_unwatched_season',['id'=>$season->content_id])); ?>">
                            <img  class = "img-fluid" src = "<?php echo e(asset('img/ww.png')); ?>" style = "width: 20px; height:auto">
                            <i> Odgledano </i>
                        </a>

                    <?php endif; ?>
                </div>

            </div>
            <div class="col-lg-4">
                    <?php if(Auth::check() && Auth::user()->is_admin==true): ?>
                    <a href="<?php echo e(route('editseason',['season'=>$content->id])); ?>">
                        <input type="submit" value="Izmeni podatke" class="btn btn-transparent">
                    </a>
                    <?php endif; ?>
                &nbsp;
            </div>
            <!-- End col-lg-12 -->
        </div>

        <br>
        <div class="row">
            <div class="col-lg-6">
                <?php $flag=false; ?>

                <?php $__currentLoopData = $content->pictures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($picture->main_picture==true){ $flag=true; ?>
                    <img src="<?php echo e(asset('img/img/content/'.$picture->path)); ?>" style="width:80%;height:auto">
                    <?php } ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if(!$flag) { ?>
                <img src="<?php echo e(asset('img/default_content.png')); ?>" style="width:60%;height:auto">

                <?php }?>

            </div>
            <div class="col-lg-6">
                <h2>Opis</h2>
                <p style="width:100%;word-wrap: break-word;font-size:16px;">
                    <?php echo e($content->description); ?>

                </p>
            </div>
        </div>
        <br>
        <br>



        <div class="row">

            <div class="col-md-7">
                <?php for($i=0;$i<count($contents);$i++): ?>
                <div class="row">
                    <div class="col-md-12" style="margin-bottom:30px">
                        <div class="col-md-4">
                            <?php if($episodes[$i]->mainPicture()->first()!=null): ?>
                                <img src="<?php echo e(asset('img/img/content/'.$episodes[$i]->mainPicture()->first()->path)); ?>" style="width:100%">
                            <?php else: ?>
                                <img src="<?php echo e(asset('img/default_content.png')); ?>" style="width:100%;height:auto;">
                            <?php endif; ?>

                        </div>
                        <div class="col-md-8">
                            <a href="<?php echo e(route('showepisode',['id'=>$contents[$i]->id])); ?>"><h4><?php echo e($contents[$i]->name); ?></h4></a>
                            <p style="width:100%;word-wrap: break-word;">
                                <?php echo e($contents[$i]->description); ?>

                            </p>

                        </div>

                    </div>

                </div>
                    <?php endfor; ?>
            </div>

            <?php if(Auth::check()): ?>

                <div class="modal" id="myModal2" style="margin-top:15%;color:black;">
                    <div class="modal-dialog">
                        <div class="modal-content" style="background-color:#2B2C30;color:white">
                            <div class="modal-header">
                                <h5 class="modal-title" style="font-size:20px">Brisanje sezone
                                    <button style="margin-bottom:10px;" type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button></h5>
                            </div>
                            <div class="modal-body">
                                <p>Da li ste sigurni da želite da uklonite ovu sezonu?</p>
                            </div>
                            <div class="modal-footer">
                                <form method="post" action="<?php echo e(route('seasonremove',['id'=>$season->content_id])); ?>">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="submit" class="btn btn-transparent" value="Potvrdi">
                                    <button type="button" class="btn btn-transparent" data-dismiss="modal">Odustani</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <div class="col-md-5">
                <!--Trejler-->
                <center>
                    <h2>Trejler</h2>
                    <?php if(Auth::check() && Auth::user()->is_admin==true): ?>
                    <a href="<?php echo e(route('addtrailer',['id'=>$season->content_id])); ?>">
                        <input type="submit" value="Dodaj trejler " class="btn btn-transparent">
                    </a>
                        <?php endif; ?>
                    <br>
                    <br>
                    <iframe width="560" height="315" src="https://www.youtube.com/embed/<?php echo e($content->trailer); ?>" style="width:100%;" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>

                </center>
            </div>

        </div>
        <br>
        <div class="row">
            <div class="col-md-12">
                <center>
                    <?php if($content->pictures !=null ): ?>
                    <h2>Slike</h2>
                    <?php endif; ?>
                    <br>
                        <?php if(Auth::check() && Auth::user()->is_admin==true): ?>
                            <center>
                                <a href="<?php echo e(route('addpictures',['id'=>$content->id])); ?>">
                                    <input type="submit" value="Dodaj sliku" class="btn btn-transparent">
                                </a>

                            </center>
                        <?php endif; ?>
                </center>
                <br>
                <br>
            </div>
            <!--Galerija-->
            <div class="col-md-12">
                <center>
                <?php $__currentLoopData = $content->pictures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3" style="margin-bottom:10px;">
                        <a href="<?php echo e(asset('img/img/content/'.$picture->path)); ?>" data-lightbox="movie">
                            <img src="<?php echo e(asset('img/img/content/'.$picture->path)); ?>" style="max-width:95%;height:auto;">
                        </a>
                    </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </center>


                </center>

            </div>
        </div>
        <br>
        <br>



    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>