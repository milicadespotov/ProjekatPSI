<?php $__env->startSection('content'); ?>
  <div class="container">
        <br>
        <div class="row">
            <div class="col-md-12 ">

                <div class="blog-title">
                    <h1>ODGLEDANE EPIZODE</h1>
                </div>
                <hr>
                <br>
                <br>
            </div>
        </div>
            <?php $__currentLoopData = $watched; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $episode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">

                <div class="col-md-12">


                <article class="entry wow fadeInDown"  data-wow-duration="1000ms" data-wow-delay="300ms">
                    <div class="col-md-4">
                    <div class="post-thumb" >
                        <a href="#">
                            <!-- PROVJERITI U KOM FOLDERU JE SLIKA I PROMIJENITI PUTANJU -->
                            <a href=<?php $path = 'img/img/content/'.$episode->path; echo $path; ?> data-lightbox="movie">
                            <img src=<?php $path = 'img/img/content/'.$episode->path; echo $path; ?>  style="width:400px;height:auto" class="img-responsive">
                            </a>
                        </a>
                    </div>
                    </div>
                    <div class="col-md-8">
                    <div class="post-excerpt">
                        <!-- DODATI RUTU KOJA VODI NA EPIZODU-->
                        <h3><a href="<?php echo e(route('showepisode',['id'=>$episode->content_id])); ?>"><?php echo e($episode->name); ?></a></h3>

                       <br>



                        <p style="word-wrap: break-word;"> <?php echo e($episode->description); ?> </p>
                    </div>
                    <div class="post-meta">
                        <span class="post-date">
										<i class="fa fa-calendar"></i><?php echo e(\Carbon\Carbon::parse($episode->release_date)->format('d/m/Y')); ?>

                        </span>
                        <span class="comments">
										<i class="fa fa-star"></i><?php echo e($episode->rating); ?>

                        </span>
                        <span class="comments">
                            <i class="fa fa-image"></i><?php echo e($episode->number_of_pictures); ?>

                        </span>

                    </div>
                    </div>
                </article>





                </div>

                </div>
                <br><br>

                <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        <div class="row">
            <div class="col-md-12">
                <center>
                    <?php echo e($watched->links()); ?>

                </center>
            </div>
        </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>