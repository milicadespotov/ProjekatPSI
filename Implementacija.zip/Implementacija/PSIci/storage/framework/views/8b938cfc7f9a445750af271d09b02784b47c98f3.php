<header id="navigation" class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header" style="margin-left:7%">
            <!-- responsive nav button -->
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <!-- /responsive nav button -->

            <!-- logo -->
            <a class="navbar-brand pull-left" href="#body">
                <h1 id="logo">
                    <img src="<?php echo e(asset('img/probni_logo.png')); ?>" style="width:175px;height:auto" alt="WSS" />
                </h1>
            </a>
            <!-- /logo -->
        </div>

        <!-- main nav -->
        <nav class="collapse navbar-collapse navbar-right" role="Navigation">
            <ul id="nav" class="nav navbar-nav">
                <li >
                    <a href="<?php echo e(route('home')); ?>">Početna</a>
                </li>

                <li>
                    <a href="<?php echo e(route('mostpopular')); ?>">Najpopularnije</a>
                </li>
                <li>
                    <a href="<?php echo e(route('upcoming')); ?>">Predstojeće</a>
                </li>

                 <!--UKLONJEN DIO OPCIJE ODAVDE-->
                <?php if(!Auth::check()): ?>
                <li>
                    <a href="<?php echo e(route('login')); ?>">Uloguj se</a>
                </li>
                <li>
                    <a href="<?php echo e(route('register')); ?>">Prijavi se</a>
                </li>
                <?php endif; ?>
                <?php if(Auth::check()): ?>
                    <?php if(Auth::user()->is_admin==true): ?>

                        <li class="dropdown">
                            <a href="#" data-toggle="dropdown"><?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->surname); ?>

                                <span class="fa fa-caret-down"></span>
                            </a>

                            <ul class="dropdown-menu">
                                <li class="dropdown-item">
                                    <a href="<?php echo e(route('userProfile')); ?>"> PROFIL </a>
                                </li>
                                <li class="dropdown-item">
                                    <a href="<?php echo e(route('addseries')); ?>"> DODAVANJE NOVIH SERIJA </a>
                                </li>
                                <li class="dropdown-item">
                                    <a href="#myModal" data-toggle="modal"> UKLONI NALOG </a>
                                </li>
                                <li class="dropdown-item">
                                    <a href="<?php echo e(route('logout')); ?>"> IZLOGUJ SE </a>
                                </li>
                                <li class="dropdown-item">
                                    <a href="<?php echo e(route('accountManager')); ?>"> UPRAVLJANJE NALOZIMA </a>
                                </li>
                                <li class="dropdown-item">
                                    <a href="<?php echo e(route('password_reset')); ?>"> PROMENI LOZINKU </a>
                                </li>

                            </ul>
                        </li>
                        <?php endif; ?>
                    <?php if(Auth::user()->is_admin==false): ?>
                            <li class="dropdown">
                                <a href="#" data-toggle="dropdown"><?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->surname); ?>

                                    <span class="fa fa-caret-down"></span>
                                </a>

                                <ul class="dropdown-menu">
                                    <li class="dropdown-item">
                                        <a href="<?php echo e(route('userProfile')); ?>"> PROFIL </a>
                                    </li>
                                    <li class="dropdown-item">
                                        <a href="#myModal" data-toggle="modal"> UKLONI NALOG </a>
                                    </li>

                                    <li class="dropdown-item">
                                            <a href="<?php echo e(route('logout')); ?>" > IZLOGUJ SE </a>
                                    </li>

                                    <li class="dropdown-item">
                                        <a href="<?php echo e(route('password_reset')); ?>"> PROMENI LOZINKU </a>
                                    </li>

                                </ul>
                            </li>


                    <?php endif; ?>
                    <?php endif; ?>
                <li style="padding-top:15px;margin-left:20px">
                    <div class="widget-content">

                        <form action="<?php echo e(route('search')); ?>" id="search-form" method="get" role="search">

                            <table>
                                <tr>
                                    <td>
                                        &nbsp;
                                    </td>
                                    <td>
                                        <select class="form-control" name="selectionForm">
                                            <option value="na">Odaberite</option>
                                            <option value="serija">Serije</option>
                                            <option value="glumci">Glumci</option>
                                            <option value="reziseri">Režiseri</option>
                                            <option value="dokumentarna">Dokumentarna</option>
                                            <option value="komedija">Komedija</option>
                                            <option value="horor">Horor</option>
                                            <option value="akcija">Akcija</option>
                                            <option value="triler">Triler</option>
                                            <option value="drama">Drama</option>
                                            <option value="romansa">Romansa</option>
                                            <option value="animirana">Animirana</option>
                                        </select>
                                    </td>
                                    <td>
                                        &nbsp;
                                    </td>
                                    <td>
                                        <input type="text" class="form-control" placeholder="Pretraga..." autocomplete="on" name="search" value="">
                                        <button type="submit" title="Search" id="search-submit">
                                            <i class="fa fa-search"></i>
                                        </button>
                                    </td>

                                </tr>
                            </table>
                        </form>
                    </div>
                </li>
            </ul>
        </nav>
    </div>      <!-- /main nav -->
</header>

<div class="container-fluid">

    <?php if(Auth::check()): ?>

    <div class="modal" id="myModal" style="margin-top:15%;color:black;">
        <div class="modal-dialog">
            <div class="modal-content" style="background-color:#2B2C30;color:white">
                <div class="modal-header">
                    <h5 class="modal-title" style="font-size:20px">Uklanjanje naloga
                        <button style="margin-bottom:10px;" type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button></h5>
                </div>
                <div class="modal-body">
                    <p>Da li ste sigurni da želite da uklonite svoj nalog?</p>
                </div>
                <div class="modal-footer">
                    <form method="post" action="<?php echo e(route('accremove',['id'=>Auth::user()->id])); ?>">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="submit" class="btn btn-transparent" value="Potvrdi">
                        <button type="button" class="btn btn-transparent" data-dismiss="modal">Odustani</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
        <?php endif; ?>
</div>

