<?php use Carbon\Carbon;
use App\Category;
?>



<?php $__env->startSection('content'); ?>



    <div class="container-fluid">
        <br>
        <br>
        <br>
        <div class="row">
            <div class="col-lg-4 ">

                <div class="blog-title">
                    <h1><?php echo e($content->name); ?></h1>
                    <?php if(Auth::check() && Auth::user()->is_admin==true): ?>
                        <a href="#myModal3" data-toggle="modal">
                            <input type="submit" value="Obrisi seriju" class="btn btn-transparent">
                        </a>
                    <?php endif; ?>
                </div>

            </div>
            <div class="col-lg-4">
                <div class="blog-title">
                    <?php echo $__env->make('rating.rate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>
            <div clas="col-lg-4">
                &nbsp;
            </div>
            <!-- End col-lg-12 -->
        </div>
        <br>
        <br>
        <td>

            <div class = "info-value" style = "padding: 5px; padding-left: 10px ; font-family: 'Lucida Sans Unicode' !important">|
                <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($genre->name); ?> |
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </td>
        <?php if(Auth::check()): ?>

            <div class="modal" id="myModal3" style="margin-top:15%;color:black;">
                <div class="modal-dialog">
                    <div class="modal-content" style="background-color:#2B2C30;color:white">
                        <div class="modal-header">
                            <h5 class="modal-title" style="font-size:20px">Brisanje serije
                                <button style="margin-bottom:10px;" type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button></h5>
                        </div>
                        <div class="modal-body">
                            <p>Da li ste sigurni da želite da uklonite ovu seriju?</p>
                        </div>
                        <div class="modal-footer">
                            <form method="post" action="<?php echo e(route('seriesremove',['id'=>$content->id])); ?>">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="submit" class="btn btn-transparent" value="Potvrdi">
                                <button type="button" class="btn btn-transparent" data-dismiss="modal">Odustani</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <div class="row" style="font-size: 20px">

            <div class="col-md-5">
                <!--Glavna slika	-->
                <center><?php $flag=false; ?>
                    <?php $__currentLoopData = $content->pictures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($picture->main_picture==true){ $flag=true;?>

                             <img src="<?php echo e(asset('img/img/content/'.$picture->path)); ?>" style="width:100%;height:auto">

                        <?php }?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!$flag) { ?>

                  <img src="<?php echo e(asset('img/default_content.png')); ?>" style="width:60%;height:auto">

                            <?php } ?>
                </center>
                <br>
                <!--Glavna slika serije-->
                <div class="col-md-12">
                    <div class = "info-name"> Režiseri: </div>
                    <div class = "info-value">
                    <?php $__currentLoopData = $series->directors(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $director): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($director->name); ?> |
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="col-md-12">

                    <div class ="info-name"> <div class = "info-name"> Glumci: </div> </div>
                    <div class ="info-value">   
                    <?php $__currentLoopData = $series->actors(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($actor->name); ?> |
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <table style="border-collapse: separate;border-spacing:25px">
                    <tr>
                        <td>
                            <div class = "info-name">TV Serija: &nbsp;  </div>
                            <div class = "info-value">
                            <?php if($content->release_date!=null): ?>
                                <?php echo e(Carbon::createFromFormat('Y-m-d H:i:s', $content->release_date)->year); ?>

                            <?php endif; ?>
                            -
                            <?php if($series->end_date!=null): ?>
                                <?php echo e(Carbon::createFromFormat('Y-m-d H:i:s', $series->end_date)->year); ?>

                            <?php endif; ?>
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <div class = "info-name"> Zemlja: </div>
                            <div class = "info-value">
                            <?php if($series->country!=null): ?>
                                <?php echo e($series->country); ?>

                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class = "info-name">
                                Trajanje:
                            </div>
                            <div class = "info-value">
                            <?php if($series->length!=null): ?>
                                <?php echo e($series->length); ?>

                                <?php endif; ?>
                            min
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <div class = "info-name"> Jezik: </div>
                            <div class = "info-value">
                            <?php if($series->language!=null): ?>
                                <?php echo e($series->language); ?>

                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <?php if(Auth::check() && Auth::user()->is_admin==true): ?>
                            <a href="<?php echo e(route('editseries',['tvshow'=>$series->content_id])); ?>">
                                <input type="submit" value="Izmeni podatke" class="btn btn-transparent">
                            </a>

                            &nbsp;
                                <?php endif; ?>
                        </td>
                    </tr>
                </table>
            </div>


            <div class="col-md-5" style="font-weight: bold">
                <!--Sezone-->
                <table class="table-dark  " style="width:100%;text-align: center">
                    <th colspan="3" style="text-align: center">
                        <h3>Sezone</h3>
                    </th>

                    <?php for($i=0;$i<count($seasons);$i++): ?>
                        <tr>
                            <td style="width:30%"><a href="<?php echo e(route('season',['id'=>$contents[$i]->id])); ?>"><?php echo e($contents[$i]->name); ?></a></td>
                            <td style="padding-top:16px">
                                <?php if(Auth::check()): ?>
                                    <div class="progress">
                                        <?php if($seasons[$i]->number_of_episodes == 0 || $seasons[$i]->number_of_episodes==null): ?>
                                            <div class="progress-bar" style="width:0%"><font style="color:#2B2C30">0%</font></div>
                                        <?php else: ?>
                                        <div class="progress-bar" style="width:<?php echo e($seasons[$i]->watchedPercentage()/$seasons[$i]->number_of_episodes*100); ?>%"><font style="color:#2B2C30"><?php echo e($seasons[$i]->watchedPercentage()/$seasons[$i]->number_of_episodes*100); ?>%</font></div>
                                    <?php endif; ?>
                                    </div>
                                <?php else: ?>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-striped"  style="width:0%; background-color: #8A2BE2" >0%</div>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td style="width:15%;padding-left:5px">
                                <?php if(Auth::check()): ?>
                                    <?php echo e($seasons[$i]->watchedPercentage()); ?>/<?php if($seasons[$i]->number_of_episodes ==0 || $seasons[$i]->number_of_episodes==null): ?>0
                                    <?php else: ?>
                                        <?php echo e($seasons[$i]->number_of_episodes); ?>

                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php if($seasons[$i]->number_of_episodes ==0 || $seasons[$i]->number_of_episodes==null): ?>0/0
                                    <?php else: ?>
                                    0/<?php echo e($seasons[$i]->number_of_episodes); ?>

                                        <?php endif; ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endfor; ?>
                </table>
                <?php if(Auth::check() && Auth::user()->is_admin==true): ?>
                <center>
                    <form method="get" action="<?php echo e(route('addSeason',['id'=>$content->id])); ?>">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="submit" value="Dodaj sezonu" class="btn btn-transparent">
                    </form>
                </center>
                    <?php endif; ?>
            </div>


        </div>
        <br>
        <div class="row">
            <div class="col-md-6">
                <center>
                    <h2>Opis:</h2>
                    <br>
                    <br>
                </center>
                <!--Opis-->
                <p style="width:100%;word-wrap: break-word;font-size:16px;">
                    <?php echo e($content->description); ?>

                </p>

            </div>
            <div class="col-md-6">
                <!--Trejler-->
                <center>

                        <h2>Trejler</h2>

                    <?php if(Auth::check() && Auth::user()->is_admin==true): ?>
                        <a href="<?php echo e(route('addtrailer',['id'=>$content->id])); ?>">
                            <input type="submit" value="Dodaj trejler" class="btn btn-transparent">
                        </a>
                    <?php endif; ?>
                    <br>
                    <br>
                    <iframe width="560" height="315" src="https://www.youtube.com/embed/<?php echo e($content->trailer); ?>" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>

                </center>

            </div>
        </div>
        <br>
        <br>
        <div class="row">
            <div class="col-md-12">
                <center>
                    <?php if($content->pictures != null): ?>
                    <h2>Slike</h2>
                    <?php endif; ?>
                    <?php if(Auth::check() && Auth::user()->is_admin==true): ?>
                        <center>
                            <a href="<?php echo e(route('addpictures',['id'=>$content->id])); ?>">
                                <input type="submit" value="Dodaj sliku" class="btn btn-transparent">
                            </a>
                        </center>
                    <?php endif; ?>
                </center>
                <br>
                <br>
            </div>
            <!--Galerija-->
            <div class="col-md-12">


                    <?php $__currentLoopData = $content->pictures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3" style="margin-bottom:10px;">
                    <a href="<?php echo e(asset('img/img/content/'.$picture->path)); ?>" data-lightbox="movie">
                        <img src="<?php echo e(asset('img/img/content/'.$picture->path)); ?>" style="max-width:95%;height:auto;margin-top:15px">
                    </a>
                        </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>



    </div>
    <br>
    <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>