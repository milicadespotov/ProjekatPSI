<?php $__env->startSection('content'); ?>
    <script language="javascript">
        function submitVal(num) {
            document.getElementById("setPictureOption").value=""+num;
            document.getElementById("changePictureForm").submit();
        }
    </script>
    <div class="container">
            <div class="row justify-content-center" style="margin-top:20px;">
                <div class="col-lg-6">

                    <div class="form-group">

                        <form enctype="multipart/form-data" method="post" id="changePictureForm" action="<?php echo e(route('avatar_episode',['episode' => $content->id])); ?>" class = "contact-form fadeInUp" data-wow-duration="500ms" data-wow-delay="300ms">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <?php echo csrf_field(); ?>
                            <label for="main_picture" style = "font-size: 18px" class="col-form-label text-md-right color">Naslovna slika:</label><br>
                            <?php if($avatarPath!=null): ?>
                                <img src="<?php echo e(asset('img/img/content/'.$avatarPath->path)); ?>" id="img" style="width:50%">
                            <?php else: ?>
                                <img src="<?php echo e(asset('img/default_content.png')); ?>" style="width:50%" id="img">
                            <?php endif; ?>
                            <input type="file" name="mainImage" class="form-control input-file" id="picture" style = "display: none;"><br>
                            <input type = "button" name = "browse_file" id = "browse_file" class = "btn btn-transparent form-control" style = "width: 30%" value = "Dodaj fotografiju">

                            <br>
                            <input type="button" onclick="submitVal(1)" class="btn btn-transparent" value="Promeni">
                            <input type="button" onclick="submitVal(0)" class="btn btn-transparent" value="Resetuj">
                            <input type="text" name="typeOfOperation" value="" id="setPictureOption" hidden>
                        </form>
                    </div>
                    <div class="form-group">
                        <form enctype="multipart/form-data" method="post" action="<?php echo e(route('add_pic_episode',['episode' => $content->id])); ?>" class = "contact-form fadeInUp" data-wow-duration="500ms" data-wow-delay="300ms">
                            <label for="pictures" style = "font-size: 18px" class="col-form-label text-md-right color">Dodaj ostale slike:</label><br>
                            <input type="file" style="margin-top:3px;" name="pictures[]" multiple class="form-control input-file" id="pictures">
                            <br>
                            <input type="submit" class="btn btn-transparent" value="Dodaj slike">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="form-group">
                        <a href="<?php echo e(route('showepisode',['id' => $content->id])); ?>"><center><button type="button" class="btn btn-transparent" value="">Vrati se na epizodu</button></center></a>
                    </div>
                    <form enctype="multipart/form-data" method="post" action="<?php echo e(route('change_episode',['episode' => $content->id])); ?>" class = "contact-form fadeInUp" data-wow-duration="500ms" data-wow-delay="300ms">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="name" style = "font-size: 18px" class="col-form-label text-md-right color">Naziv epizode:</label>
                            <input type="text" id="name" name="name" class="form-control" value="<?php if (old('name')==null) echo $content->name; else echo old('name');?>" style = "<?php echo e($errors->has('name') ? 'border-color: deeppink' : ''); ?>">
                            <?php if($errors->has('name')): ?>
                                <span class="invalid-feedback" style="color:deeppink">
                                        <?php echo e($errors->first('name')); ?>

                                    </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="trailer" style = "font-size: 18px" class="col-form-label text-md-right color">Trejler:</label>
                            <input type="text" value="<?php if (old('trailer')==null) echo $content->trailer; else echo old('trailer');?>" id="trailer" name="trailer" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="description" style = "font-size: 18px" class="col-form-label text-md-right color">Opis:</label>
                            <textarea name="description" id="description" class="form-control"><?php if (old('description')==null) echo $content->description; else echo old('description');?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="numEpisode" style = "font-size: 18px" class="col-form-label text-md-right color">Redni broj epizode:</label>
                            <input type="text" name="numEpisode" value="<?php if (old('numEpisode')==null) echo $episode->episode_number; else echo old('numEpisode');?>" class="form-control" style = "<?php echo e($errors->has('numEpisode') ? 'border-color: deeppink' : ''); ?>">
                            <?php if($errors->has('numEpisode')): ?>
                                <span class="invalid-feedback" style="color:deeppink">
                                        <?php echo e($errors->first('numEpisode')); ?>

                                    </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="duration" style = "font-size: 18px" class="col-form-label text-md-right color">Duzina epizode:</label>
                            <input type="text" name="duration" class="form-control" value="<?php if (old('duration')==null) echo $episode->length; else echo old('duration');?>" style = "<?php echo e($errors->has('duration') ? 'border-color: deeppink' : ''); ?>">
                            <?php if($errors->has('duration')): ?>
                                <span class="invalid-feedback" style="color:deeppink">
                                        <?php echo e($errors->first('duration')); ?>

                                    </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="releaseDate" style = "font-size: 18px" class="col-form-label text-md-right color">Datum izlaska:</label>
                            <input type="date" name="releaseDate" class="form-control" id="releaseDate" value="<?php if (old('releaseDate')==null) echo substr($content->release_date,0,10); else echo substr(old('releaseDate'),0,10);?>">
                        </div>
                        <input type="submit" class="btn btn-lg btn-transparent" value="Izmeni detalje">
                    </form>
                </div>
            </div>
        <div class="row justify-content-center" style="margin-top:20px;">
            <div class="col-lg-12">
            <div class="form-group">
                <label style = "font-size: 18px" class="col-form-label text-md-right color">Odaberi slike za brisanje:</label>
                <form method="post" enctype="multipart/form-data" action="<?php echo e(route('delete_pic_episode',['episode' => $content->id])); ?>" class = "contact-form fadeInUp" data-wow-duration="500ms" data-wow-delay="300ms">
                    <div class="row">
                        <?php $i=0; ?>
                        <?php $__currentLoopData = $picturePaths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picPath): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                if ($i%6==0) echo '<div class="row">';
                            ?>
                            <div class="col-lg-2">
                                <center><input type="checkbox" id=<?php echo e($picPath->path); ?> name="paths[]" value="<?php echo e($picPath->path); ?>"></center>
                                <br>
                                <label for="<?php echo e($picPath->path); ?>"><img style="width:100%" src="<?php echo e(asset('img/img/content/'.$picPath->path)); ?>"></label>
                            </div>
                            <?php
                                $i=$i+1;
                                if ($i%6==0) echo '</div>';
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <input type="submit" class="btn btn-transparent" value="Obriši slike">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>