<?php $__env->startSection('content'); ?>
    <div class = "backgroundLogin">
<div class="container"> <br> <br> <br> <br> <br>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"> <h3> <?php echo e(__('Resetovanje Password')); ?> </h3></div>
                <br> <br> <br>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('password_reset_confirm')); ?>"  class = "contact-form fadeInUp color"  data-wow-duration="500ms" data-wow-delay="300ms">
                        <?php echo csrf_field(); ?>



                        <div class="form-group row">
                            <label for="old_password" class="col-md-4 col-form-label text-md-right" style = "font-size: 18px;"><?php echo e(__('Lozinka stara:')); ?></label>

                            <div class="col-md-6">
                                <input id="old_password" type="password" class="form-control<?php echo e($errors->has('old_password') ? ' is-invalid' : ''); ?>" name="old_password" required autofocus>

                                <?php if($errors->has('old_password')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('old_password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right" style = "font-size: 18px;"><?php echo e(__('Nova lozinka: ')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password_confirm" class="col-md-4 col-form-label text-md-right" style = "font-size: 18px"><?php echo e(__('Potvrdite novu lozinku:')); ?></label>

                            <div class="col-md-6">
                                <input id="password_confirm" type="password" class="form-control" name="password_confirm" required>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary btn-transparent">
                                    <?php echo e(__('Reset Password')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
        <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br>  <br>
        <br>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>