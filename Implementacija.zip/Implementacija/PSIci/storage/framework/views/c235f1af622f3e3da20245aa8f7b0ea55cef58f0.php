<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <h2><?php echo e($content->name); ?></h2>
                <table>
                    <tr>
                        <td>
                            <b>Datum objavljivanja:</b>
                            <?php echo e($content->release_date); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <b>Opis:</b>
                            <?php echo e($content->description); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <b>Država:</b>
                            <?php echo e($tvshow->country); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <b>Jezik:</b>
                            <?php echo e($tvshow->language); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                        <b>Prosečna dužina epizode:</b>
                        <?php echo e($tvshow->length); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <b>Datum završetka:</b>
                            <?php echo e($tvshow->end_date); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <b>Broj epizoda:</b>
                            <?php echo e($tvshow->number_of_episodes); ?>

                        </td>
                    </tr>
                    <tr>
                        <td>
                            <b>Glumci:</b><br>
                            <?php $__currentLoopData = $actors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($actor->name); ?><br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <b>Režiseri:</b><br>
                            <?php $__currentLoopData = $directors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $director): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($director->name); ?><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>


                </table>
            </div>
            <div class="col-lg-6">
                <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('addActor',['id' => $content->id])); ?>" class = "contact-form fadeInUp" data-wow-duration="500ms" data-wow-delay="300ms">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="actor">Glumac:</label>
                        <input type="text" name="actor" class="form-control">
                        <input style="margin-top:15px" type="submit" class="btn btn-transparent" value="Dodaj glumca">
                    </div>

                </form>
                <br>
                <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('addDirector',['id' => $content->id])); ?>" class = "contact-form fadeInUp" data-wow-duration="500ms" data-wow-delay="300ms">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="actor">Režiser:</label>
                        <input type="text" name="director" class="form-control">
                        <input style="margin-top:15px" type="submit" class="btn btn-transparent" value="Dodaj režisera">
                    </div>

                </form>
                <br>
                <center>  <a href="<?php echo e(route('showseries',['content_id'=>$content->id])); ?>"><button class="btn btn-transparent">Potvrdi</button></a></center>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>