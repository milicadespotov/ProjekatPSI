<?php $__env->startSection('content'); ?>

    <br>
    <br>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-5">
                <div class="col-md-6"><!--SREDITI DA SE UBACI DEAFULT PROFILNA SLIKA!!!!--> <br>
                    <img   class = "img-fluid img-rounded" src=<?php if(is_null($user->picture_path)){ echo 'img/avatar.png' ;} else {$path = 'img/img/users/'.$user->picture_path; echo $path; } ?> style="width:100%">
                    <div class = "info-name">
                        <i> Član WhySoSeries od</i>
                    </div>
                    <div class = "info-name">
                        <i> <?php echo e(\Carbon\Carbon::parse($user->registration_date)->format('d/m/Y')); ?> </i>
                    </div>

                    <h4>
                        <?php if(Auth::check() && Auth::user()->is_admin==false): ?>
                            Status: Korisnik
                        <?php endif; ?>
                            <?php if(Auth::check() && Auth::user()->is_admin==true): ?>
                                <div class = "info-name"> Status: </div> <div class = "info-value"> Admin </div>
                            <?php endif; ?>

                    </h4>
                    <p>
                        <a href="<?php echo e(route('infoupdate')); ?>">
                            <input type="submit" value="Izmeni informacije" class="btn btn-transparent">
                        </a>

                    </p>
                    <p>
                        <?php if(Auth::check() && Auth::user()->is_admin==true): ?>
                            <a href="<?php echo e(route('addseries')); ?>">
                                <input type="submit" value="Dodavanje novih serija" class="btn btn-transparent">
                            </a>
                        <?php endif; ?>

                        <a href="<?php echo e(route('watchedepisodes')); ?>">
                            <input type="submit" value="Odgledano" class="btn btn-transparent">
                        </a>
                        

                    </p>
                </div>
                <div class="col-md-6">

                    <div class = "color">  <h2><?php echo e($user->name.' '.$user->surname); ?></h2> <br> <br> </div>
                    <div class = "info-name">
                        Email adresa:  &nbsp;
                    </div>
                    <div class = "info-value">
                        <?php echo e($user->email); ?>

                    </div>
                    <br>
                    <div class = "info-name">
                        Datum rodjenja: &nbsp;
                    </div>

                    <div class = "info-value">
                        <?php if(!is_null($user->birth_date)) echo \Carbon\Carbon::parse($user->birth_date)->format('d/m/Y'); ?>
                    </div> <br>
                    <div class = "info-name">Pol:  &nbsp;    </div>
                    <div class = "info-value">
                    <?php if($user->gender == 'f'): ?>
                        Ženski
                    <?php else: ?>
                        Muški
                    <?php endif; ?>
                    </div>

                    <br>



                </div>
            </div>
            <div class="col-md-7 ">
                <center>
                    <h3>

                        <?php if(Auth::check() && Auth::user()->is_admin==true): ?>
                            Poslednje modifikovane serije
                            <?php endif; ?>

                        <?php if(Auth::check() && Auth::user()->is_admin==false): ?>
                            Poslednje ocenjene serije
                        <?php endif; ?>
                    </h3>
                </center>
                <br>
                <div>
                    <center><!--Sve ocijenjene serije-->
                        <div class = "row">
                        <?php if(count($lastRated) == 0): ?>
                            <h4>Nemate ocenjenih/modifikovanih serija!</h4>
                        <?php else: ?>

                            <?php for($i=0;$i<sizeof($lastRated);$i++): ?>
                                <div class = "col-md-4">
                             <a href="<?php echo e(route('showseries',['id'=>$lastRated[$i]->content_id])); ?>" >
                                 <img src=<?php if(is_null($picturesLR[$i])){ echo 'img/default_content.png' ;} else {$path = 'img/img/content/'.$picturesLR[$i]->path; echo $path; } ?> style="width:100%;height:auto;margin-left:10px;margin-bottom:5px">
                             </a>
                                </div>
                            <?php endfor; ?>
                        <?php endif; ?>
                        </div>
                    </center>
                </div>
                <br>
                <br>

                <br>
                <br>

                <center>
                    <h3>

                    <?php if(Auth::check() && Auth::user()->is_admin==true): ?>
                            Poslednje dodate serije
                        <?php endif; ?>


                    <?php if(Auth::check() && Auth::user()->is_admin==false): ?>
                            Poslednje odgledane epizode serije
                        <?php endif; ?>
                    </h3>
                </center>
                <br>
                <div>
                    <center><!--Sve odgledane epizode-->
                        <div class = "row">
                        <?php if(Auth::check() && Auth::user()->is_admin==false): ?>

                        <?php if(count($lastWatched)==0): ?>
                            <h4>Nemate odgledanih epizoda!</h4>
                        <?php else: ?>

                        <?php for($i=0;$i<sizeof($lastWatched);$i++): ?>
                                    <div class = "col-md-4">
                            <a href="<?php echo e(route('showepisode',['id'=>$lastWatched[$i]->content_id])); ?>" >
                                <img src=<?php if(is_null($picturesLW[$i])){ echo 'img/default_content.png' ;} else {$path = 'img/img/content/'.$picturesLW[$i]->path; echo $path; } ?> style="width:100%;height:auto;margin-left:10px;margin-bottom:5px">

                            </a>
                                    </div>
                        <?php endfor; ?>
                        <?php endif; ?>

                        <?php endif; ?>
                        </div>

                        <?php if(Auth::check() && Auth::user()->is_admin==true): ?>


                            <div class = "row">
                            <?php if(count($lastAdded)==0): ?>
                                <h4>Nema dodatih serija!</h4>
                            <?php else: ?>
                                <?php for($i=0;$i<sizeof($lastAdded);$i++): ?>


                                    <div class = "col-md-4">
                                    <a href="<?php echo e(route('showseries',['id'=>$lastAdded[$i]->content_id])); ?>" >
                                        <img src=<?php if(is_null($picturesLA[$i])){ echo 'img/default_content.png' ;} else {$path = 'img/img/content/'.$picturesLA[$i]->path; echo $path; } ?> style="width:100%;height:auto;margin-left:10px;margin-bottom:5px">

                                    </a>
                                    </div>
                                <?php endfor; ?>
                            <?php endif; ?>
                            </div>
                        <?php endif; ?>



                    </center>
                </div>
            </div>
        </div>

    </div>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>