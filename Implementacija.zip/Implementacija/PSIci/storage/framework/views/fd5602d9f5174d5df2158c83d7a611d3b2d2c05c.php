<?php $__env->startSection('content'); ?>
    <script language="javascript">
        function submitVal(num) {
            document.getElementById("setPictureOption").value=""+num;
            document.getElementById("changePictureForm").submit();
        }
    </script>
    <div class="container">
        <div class="row justify-content-center" style="margin-top:20px;">
            <div class="col-lg-6">
                <div class="row">
                    <div class="col-lg-offset-4 col-lg-4">
                        <?php if($avatarPath!=null): ?>
                            <img src="<?php echo e(asset('img/img/content/'.$avatarPath->path)); ?>" style="width:100%">
                        <?php else: ?>
                            <img src="<?php echo e(asset('img/default_content.png')); ?>" style="width:100%">
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group">
                    <label for="mainImage" style = "font-size: 18px" class="col-form-label text-md-right color">Naslovna slika:</label><br>
                    <form enctype="multipart/form-data" method="post" id="changePictureForm" action="<?php echo e(route('avatar_tvshow',['tvshow' => $content->id])); ?>" class = "contact-form fadeInUp" data-wow-duration="500ms" data-wow-delay="300ms">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="file" name="mainImage" class="form-control input-file" id="mainImage">
                        <input type="button" onclick="submitVal(1)" class="btn btn-transparent" value="Promeni">
                        <input type="button" onclick="submitVal(0)" class="btn btn-transparent" value="Resetuj">
                        <input type="text" name="typeOfOperation" value="" id="setPictureOption" hidden>
                    </form>
                </div>
                <div class="form-group">
                    <form enctype="multipart/form-data" method="post" action="<?php echo e(route('add_pic_tvshow',['tvshow' => $content->id])); ?>" class = "contact-form fadeInUp" data-wow-duration="500ms" data-wow-delay="300ms">
                        <label for="pictures" style = "font-size: 18px" class="col-form-label text-md-right color">Dodaj ostale slike:</label><br>
                        <input type="file" style="margin-top:3px;" name="pictures[]" multiple class="form-control input-file" id="pictures">
                        <br>
                        <input type="submit" class="btn btn-transparent" value="Dodaj slike">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
                <div class="form-group">

                    <form enctype="multipart/form-data" method="post" action="<?php echo e(route('tvshow_genre',['tvshow' => $content->id])); ?>" class = "contact-form fadeInUp" data-wow-duration="500ms" data-wow-delay="300ms">

                        <label for="genre" style = "font-size: 18px" class="col-form-label text-md-right color">Žanr:</label>

                        <table cell-padding="20px">

                            <?php $i=0; ?>
                            <?php $__currentLoopData = $checkBoxArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                if ($i%4==0) echo '<tr>';
                                ?>
                                <td style="padding:10px">
                                    <label for="<?php echo e($cb['name']); ?>"><?php echo ucfirst($cb['name']);?>:</label></td><td style="padding:10px">
                                    <input type="checkbox" name="genre[]" value="<?php echo e($cb['id']); ?>" id="<?php echo e($cb['name']); ?>"
                                    <?php if($cb['check']!=null): ?> <?php echo e('checked'); ?>

                                    <?php endif; ?>>
                                </td>
                                <?php
                                    $i=$i+1;
                                    if ($i%4==0) echo '</tr>'
                                ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                if ($i%4!=0) echo '</tr>';
                            ?>
                        </table>
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <input type="submit" class="btn btn-transparent" value="Promeni žanr">
                    </form>
                </div>
                <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('tvshow_actor_add',['tvshow' => $content->id])); ?>" class = "contact-form fadeInUp" data-wow-duration="500ms" data-wow-delay="300ms">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="actor">Glumac:</label>
                        <input type="text" name="actor" class="form-control">
                        <input style="margin-top:15px" type="submit" class="btn btn-transparent" value="Dodaj glumca">
                    </div>

                </form>
                <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('tvshow_director_add',['tvshow' => $content->id])); ?>" class = "contact-form fadeInUp" data-wow-duration="500ms" data-wow-delay="300ms">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="actor">Režiser:</label>
                        <input type="text" name="director" class="form-control">
                        <input style="margin-top:15px" type="submit" class="btn btn-transparent" value="Dodaj režisera">
                    </div>

                </form>
            </div>
            <div class="col-lg-6">
            <div class="form-group">
                <a href="<?php echo e(route('showseries',['id' => $content->id])); ?>"><center><button type="button" class="btn btn-transparent" value="">Vrati se na seriju</button></center></a>
            </div>
            <form enctype="multipart/form-data" method="post" action="<?php echo e(route('change_tvshow',['tvshow' => $content->id])); ?>" class = "contact-form fadeInUp" data-wow-duration="500ms" data-wow-delay="300ms">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="name" style = "font-size: 18px" class="col-form-label text-md-right color">Ime serije:</label>
                    <input type="text" name="name" value="<?php if (old('name')==null) echo $content->name; else echo old('name');?>" class="form-control" style="<?php echo e($errors->has('name')?'border-color: deeppink': ''); ?>;" id="name">
                    <?php if($errors->has('name')): ?>
                        <span class="invalid-feedback" style = "color: deeppink">
                                            <?php echo e($errors->first('name')); ?>

                                    </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="trailer" style="font-size:18px" class="col-form-label text-md-right color">Trejler:</label>
                    <input type="text" name="trailer" class="form-control" id="trailer" value="<?php if (old('trailer')==null) echo $content->trailer; else echo old('trailer');?>">
                </div>
                <div class="form-group">
                    <label for="description" style = "font-size: 18px" class="col-form-label text-md-right color">Kratak opis:</label>
                    <textarea name="description" class="form-control" id="description"><?php if (old('description')==null) echo $content->description; else echo old('description');?></textarea>
                </div>
                <div class="form-group">
                    <label for="releaseDate" style = "font-size: 18px" class="col-form-label text-md-right color">Datum izlaska:</label>
                    <input type="date" value="<?php if (old('releaseDate')==null) echo substr($content->release_date,0,10); else echo substr(old('releaseDate'),0,10);?>"name="releaseDate" class="form-control" id="releaseDate" >
                </div>
                <div class="form-group">
                    <label for="country" style = "font-size: 18px" class="col-form-label text-md-right color">Zemlja porekla:</label>
                    <input type="text" name="country" class="form-control" id="country" value="<?php if (old('country')==null) echo $tvshow->country; else echo old('country');?>">
                </div>
                <div class="form-group">
                    <label for="language" style = "font-size: 18px" class="col-form-label text-md-right color">Jezik:</label>
                    <input type="text" name="language" value="<?php if (old('language')==null) echo $tvshow->language; else echo old('language');?>"class="form-control" id="language">
                </div>
                <div class="form-group">
                    <label for="duration" style = "font-size: 18px" class="col-form-label text-md-right color">Trajanje epizode: (u minutima)</label>
                    <input type="text" name="duration" value="<?php if (old('duration')==null) echo $tvshow->length; else echo old('duration');?>" class="form-control" style="<?php echo e($errors->has('duration')?'border-color: deeppink': ''); ?>" id="duration">
                    <?php if($errors->has('duration')): ?>
                        <span class="invalid-feedback" style = "color: deeppink">
                                            <?php echo e($errors->first('duration')); ?>

                                    </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <label for="endDate" style = "font-size: 18px" class="col-form-label text-md-right color">Datum završetka:</label>
                    <input type="date" name="endDate" class="form-control" id="endDate" value="<?php if (old('endDate')==null) echo substr($tvshow->end_date,0,10); else echo substr(old('endDate'),0,10);?>">
                </div>
                <div class="form-group">
                    <label for="episodes" style = "font-size: 18px" class="col-form-label text-md-right color">Broj epizoda:</label>
                    <input type="text" name="episodes" value="<?php if (old('episodes')==null) echo $tvshow->number_of_episodes; else echo old('episodes');?>" class="form-control" style="<?php echo e($errors->has('episodes')?'border-color: deeppink': ''); ?>" id="episodes">
                    <?php if($errors->has('episodes')): ?>
                        <span class="invalid-feedback" style = "color: deeppink">
                                            <?php echo e($errors->first('episodes')); ?>

                                    </span>
                    <?php endif; ?>
                </div>
                <input type="submit" class="btn btn-lg btn-transparent" value="Izmeni detalje">
            </form>

            </div>
        </div>
        <div class="row justify-content-center" style="margin-top:20px;">
            <div class="col-lg-12">
                <div class="form-group">
                    <form method="post" enctype="multipart/form-data" action="<?php echo e(route('delete_pic_tvshow',['tvshow' => $content->id])); ?>" class = "contact-form fadeInUp" data-wow-duration="500ms" data-wow-delay="300ms">
                        <label style = "font-size: 18px" class="col-form-label text-md-right color">Odaberi slike za brisanje:</label>

                        <div class="row">
                            <?php $i=0; ?>
                            <?php $__currentLoopData = $picturePaths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picPath): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                if ($i%6==0) echo '<div class="row">';
                                ?>
                                <div class="col-lg-2">
                                    <center><input type="checkbox" id=<?php echo e($picPath->path); ?> name="paths[]" value="<?php echo e($picPath->path); ?>"></center>
                                    <br>
                                    <label for="<?php echo e($picPath->path); ?>"><img style="width:100%" src="<?php echo e(asset('img/img/content/'.$picPath->path)); ?>"></label>
                                </div>
                                <?php
                                $i=$i+1;
                                if ($i%6==0) echo '</div>';
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <input type="submit" style="margin-left:20px" class="btn btn-transparent" value="Obriši slike">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
                <div class="form-group">

                    <form enctype="multipart/form-data" method="post" action="<?php echo e(route('tvshow_actor_delete',['tvshow' => $content->id])); ?>" class = "contact-form fadeInUp" data-wow-duration="500ms" data-wow-delay="300ms">

                        <label for="genre" style = "font-size: 18px" class="col-form-label text-md-right color">Odaberi glumce za brisanje:</label>

                        <table cell-padding="20px">

                            <?php $i=0; ?>
                            <?php $__currentLoopData = $actors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                if ($i%6==0) echo '<tr>';
                                ?>
                                <td style="padding:10px">
                                    <label for="<?php echo e($actor->name); ?>"><?php echo ucfirst($actor->name);?>:</label></td><td style="padding:10px">
                                    <input type="checkbox" name="actors[]" value="<?php echo e($actor->id); ?>" id="<?php echo e($actor->name); ?>">
                                </td>
                                <?php
                                $i=$i+1;
                                if ($i%6==0) echo '</tr>'
                                ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            if ($i%6!=0) echo '</tr>';
                            ?>
                        </table>
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <input type="submit" class="btn btn-transparent" value="Obriši glumce">
                    </form>
                </div>
                <div class="form-group">
                    <form method="post" enctype="multipart/form-data" action="<?php echo e(route('tvshow_director_delete',['tvshow' => $content->id])); ?>" class = "contact-form fadeInUp" data-wow-duration="500ms" data-wow-delay="300ms">
                        <label style = "font-size: 18px" class="col-form-label text-md-right color">Odaberi režisere za brisanje:</label>

                            <table cell-padding="20px">
                            <?php $i=0; ?>
                            <?php $__currentLoopData = $directors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $director): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                if ($i%6==0) echo '<tr>';
                                ?>
                                <td style="padding:10px">
                                    <label for="<?php echo e($director->name); ?>"><?php echo ucfirst($director->name);?>:</label></td><td style="padding:10px">
                                    <input type="checkbox" name="directors[]" value="<?php echo e($director->id); ?>" id="<?php echo e($director->name); ?>">
                                </td>
                                <?php
                                $i=$i+1;
                                if ($i%6==0) echo '</tr>'
                                ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            if ($i%6!=0) echo '</tr>';
                            ?>
                            </table>
                        <input type="submit" class="btn btn-transparent" value="Obriši režisere">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>